#!/bin/bash

FILE=$(zenity --file-selection --title="Dear SMPL user, please select a barcode folder to start Wily" --directory)

cd $FILE/ 

merge=$FILE/merged.fastq

if [ -f "$merge" ]; then
echo "$merge exists! Please delete $merge to proceed."
zenity --error --title="Delete to proceed!" --text="Delete merged.fastq and restart wily again" 
exit 0
else
cat *.fastq > merged.fastq &&
zenity --info --title="Wily is starting" --text="Running Filtlong and Porechop now - Press ok to proceed" --width=600 --height=100 
/usr/local/bin/Filtlong/bin/filtlong --min_length 1000 --keep_percent 90 merged.fastq > filtout.fastq &&
porechop -i filtout.fastq -o porechoped.fastq &&
(
echo "# Filtlong & Porechop: Filtering reads based on quality and cleaning contaminating adapters" ; sleep 2
echo "40"
echo "# Flye: Assembling the raw reads" ; sleep 1
mkdir assembly
path2=$PWD
flye --nano-raw porechoped.fastq -t 4 --out-dir $path2/assembly -t 8 && 
echo "60"
echo "# Circlator: Trying to circularise the genome assembly" ; sleep 1
circlator all --data_type nanopore-raw --bwa_opts "-x ont2d" --merge_min_id 85 --merge_breaklen 1000 $path2/assembly/assembly.fasta $path2/porechoped.fastq $path2/circularised --threads 8
echo "80"
echo "# Minimap2: Preparing assembly files for polishing." ;
minimap2 -x ava-ont $path2/circularised/06.fixstart.fasta $path2/porechoped.fastq > overlaps.paf ||
minimap2 -x ava-ont $path2/assembly/assembly.fasta $path2/porechoped.fastq > overlaps.paf
echo "90"
echo "# Racon polisher: Attempting to polish circularised genome" ;
racon $path2/porechoped.fastq overlaps.paf $path2/circularised/06.fixstart.fasta -t 8 > polish.assembly.fasta ||
racon $path2/porechoped.fastq overlaps.paf $path2/assembly/assembly.fasta -t 8 > polish.assembly.fasta &&
echo "100"
echo "# Assigned jobs completed, Wily is wrapping up" sleep 2
) |
zenity --progress \
 --title="Wily Progress Status" \
  --text="Wily is starting" \
  --percentage=0 \
  --auto-close \
   --width=600 --height=200
  

(( $? != 0 )) && zenity --error --text="Some unresolvable error occured! Please contact Gomathinayagam" --width=600 --height=200

fi

notify-send "Wily completed the job"
zenity --info --text="Wily has completed processing the fastq files, see wily.log for more info" --width=600 --height=200
exit 0
